#include <REGX51.H>
sbit bit1 = P2^0;
sbit bit2 = P2^1;
sbit bit3 = P2^2;
sbit bit4 = P2^3;
sbit bit5 = P2^4;
sbit bit6 = P2^5;
sbit bit7 = P2^6;
sbit bit8 = P2^7;
unsigned char code seg_table[] = {0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F};
void delayms(unsigned int ms) 
{
	unsigned int i, j; 
	for(i = ms; i > 0; i--) 
	{ 
		 for(j = 114; j > 0; j--);
	}
 }
void display(void)
{
	P2=0xFE;
	P0=seg_table[1];
	delayms(2);
	P2=0xFD;
	P0=seg_table[2];
	delayms(2);
	P2=0xFB;
	P0=seg_table[3];
	delayms(2);
	P2=0xF7;
	P0=seg_table[4];
	delayms(2);
	P2=0xEF;
	P0=seg_table[5];
	delayms(2);
	P2=0xDF;
	P0=seg_table[6];
	delayms(2);
	P2=0xBF;
	P0=seg_table[7];
	delayms(2);
	P2=0x7F;
	P0=seg_table[8];
	delayms(2);
}
void main(void)
{
	while(1)
	{
		display();
	}
}