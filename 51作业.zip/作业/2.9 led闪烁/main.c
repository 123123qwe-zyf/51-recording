#include <REGX51.H>
void delay_ms(unsigned int ms)
{
	unsigned int i,j;
	for(i=0;i<ms;i++)
	{
		for(j=0;j<120;j++);//��1000us
	}
}
void main()
{
	while(1)
	{
		P1=0xFF;
		delay_ms(500);
		P1=0x00;
		delay_ms(500);
	}
}