#include <REGX51.H>

sbit w1=P2^1;
sbit w2=P2^2;


unsigned char code seg_table[] =
{
	0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F
};
unsigned int cnt=0;
unsigned int cntt=0;
unsigned char disp_buf[2]={0,0};
unsigned char scan_index = 0; 

void delay(unsigned int ms);
void Timer0_Init(void);
void display(void);

void main(void)
{
	Timer0_Init();
	while(1)
	{
		disp_buf[0]=cnt/10;
		disp_buf[1]=cnt%10;
	}

}

void delay(unsigned int ms) 
{
	unsigned int i, j; 
	for(i = ms; i > 0; i--) 
	{ 
		 for(j = 114; j > 0; j--);
	}
}

void Timer0_Init(void)
{
	TMOD	&=0xF0;    //���T0ģʽλ
	TMOD  |=0x01;     //T0ģʽ1��16λ��ʱ
	TH0=0xFC;            //��ֵ��8λ
	TL0=0x18;             //��ֵ��8λ
	ET0=1;                  //����T0�ж�
	EA=1;                    //�������ж�
	TR0=1;                  //����T0
}

void Timer0_Rountine(void) interrupt 1
{
	TH0=0xFC;
	TL0=0x18;
	cntt++;
	if(cntt>=500)
	{
		cntt=0;
		cnt++;
		if(cnt>99)
			cnt=0;
	}
	display();
}
void display(void)
{
	w1=1;w2=1;
	P0=0x00;
	if(scan_index==0)
	{
		P0=seg_table[disp_buf[0]];
		w1=0;w2=1;
	}
	else
	{
		P0=seg_table[disp_buf[1]];
		w1=1;w2=0;
	}
	scan_index = 1 - scan_index;
}