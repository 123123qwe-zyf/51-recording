#include <REGX51.H>

void Delay(unsigned int ms);
unsigned char MatrixKey();
void Display8Bit(void);

unsigned char code seg_table[] =
{
    0x3F, // 0
    0x06, // 1
    0x5B, // 2
    0x4F, // 3
    0x66, // 4
    0x6D, // 5
    0x7D, // 6
    0x07, // 7
    0x7F, // 8
    0x6F, // 9
    0x77, // A (10)
    0x7C, // B (11)
    0x39, // C (12)
    0x5E, // D (13)
    0x79, // E (14)
    0x71  // F (15)
};

sbit led = P3^0;
// 8λ�����λѡ
sbit dig1 = P2^0;
sbit dig2 = P2^1;
sbit dig3 = P2^2;
sbit dig4 = P2^3;
sbit dig5 = P2^4;
sbit dig6 = P2^5;
sbit dig7 = P2^6;
sbit dig8 = P2^7;

// �����������
sbit ROW1 = P1^7;
sbit ROW2 = P1^6;
sbit ROW3 = P1^5;
sbit ROW4 = P1^4;
sbit COL1 = P1^3;
sbit COL2 = P1^2;
sbit COL3 = P1^1;
sbit COL4 = P1^0;

unsigned char correct_pwd[4] = {1,2,3,4};
unsigned char input_pwd[4] = {0};
unsigned char input_cnt = 0;
unsigned char KeyNumber = 0xFF;//0xFF=�ް���
unsigned char i;

void main(void)
{
	
    led = 0;          
    input_cnt = 0;
    // �����������
    for(i=0; i<4; i++) input_pwd[i] = 0;
    while(1)
    {
        KeyNumber = MatrixKey(); 
        if(KeyNumber != 0xFF && input_cnt < 4)
        {
            // �洢��ǰ����ֵ����������
            input_pwd[input_cnt] = KeyNumber;
            // ��λ�ȶԣ�����ǰ��������ȷ����ƥ�䣬�ż�������
            if(input_pwd[input_cnt] == correct_pwd[input_cnt])
            {
                input_cnt++; // ƥ�������+1
                // 4λ����ȫ��������ƥ��
                if(input_cnt == 4)
                {
                    led = 1;                // ����LED
                    Delay(2000);            // ����2��
                    led = 0;                // Ϩ��LED
                    input_cnt = 0;          // �����������
                    for(i=0; i<4; i++) input_pwd[i] = 0; // �����������
                }
            }
            else
            {
                // ���������������
                input_cnt = 0;
                for(i=0; i<4; i++) input_pwd[i] = 0;
                led = 0; // ȷ��LEDϨ��
            }
        }
        // ����ˢ��8λ�������ʾ����ʾ��������������У�
        Display8Bit();
    }
}

void Display8Bit(void)
{
    unsigned char seg_code;
    P0 = 0x00; // ��Ӱ
    dig1 = 0; dig2=dig3=dig4=dig5=dig6=dig7=dig8=1;
    seg_code = (input_pwd[0] <= 15) ? seg_table[input_pwd[0]] : 0x00;
    P0 = seg_code;
    Delay(1);

    P0 = 0x00;
    dig2 = 0; dig1=dig3=dig4=dig5=dig6=dig7=dig8=1;
    seg_code = (input_pwd[1] <= 15) ? seg_table[input_pwd[1]] : 0x00;
    P0 = seg_code;
    Delay(1);

    P0 = 0x00;
    dig3 =0; dig1=dig2=dig4=dig5=dig6=dig7=dig8=1;
    seg_code = (input_pwd[2] <= 15) ? seg_table[input_pwd[2]] : 0x00;
    P0 = seg_code;
    Delay(1);

    P0 = 0x00;
    dig4 = 0; dig1=dig2=dig3=dig5=dig6=dig7=dig8=1;
    seg_code = (input_pwd[3] <= 15) ? seg_table[input_pwd[3]] : 0x00;
    P0 = seg_code;
    Delay(1);

    P0 = 0x00;
    dig5 = 0; dig1=dig2=dig3=dig4=dig6=dig7=dig8=1;
    Delay(1);

    P0 = 0x00;
    dig6 = 0; dig1=dig2=dig3=dig4=dig5=dig7=dig8=1;
    Delay(1);

    P0 = 0x00;
    dig7 = 0; dig1=dig2=dig3=dig4=dig5=dig6=dig8=1;
    Delay(1);

    P0 = 0x00;
    dig8 = 0; dig1=dig2=dig3=dig4=dig5=dig6=dig7=1;
    Delay(1);
}

unsigned char MatrixKey()
{
    unsigned char key = 0xFF;
    P1 = 0xFF; // ��ʼ��P1��Ϊ�ߵ�ƽ

    // ��1�У�COL1=P1_3��
    P1_3 = 0;
    if(P1_7==0){Delay(20);if(P1_7==0){while(P1_7==0);Delay(20);key=1;}}
    if(P1_6==0){Delay(20);if(P1_6==0){while(P1_6==0);Delay(20);key=5;}}
    if(P1_5==0){Delay(20);if(P1_5==0){while(P1_5==0);Delay(20);key=9;}}
    if(P1_4==0){Delay(20);if(P1_4==0){while(P1_4==0);Delay(20);key=13;}}//D
    P1_3 = 1;

    // ��2�У�COL2=P1_2��
    P1_2 = 0;
    if(P1_7==0){Delay(20);if(P1_7==0){while(P1_7==0);Delay(20);key=2;}}
    if(P1_6==0){Delay(20);if(P1_6==0){while(P1_6==0);Delay(20);key=6;}}
    if(P1_5==0){Delay(20);if(P1_5==0){while(P1_5==0);Delay(20);key=10;}}//A
    if(P1_4==0){Delay(20);if(P1_4==0){while(P1_4==0);Delay(20);key=14;}}//E
    P1_2 = 1;

    // ��3�У�COL3=P1_1��
    P1_1 = 0;
    if(P1_7==0){Delay(20);if(P1_7==0){while(P1_7==0);Delay(20);key=3;}}
    if(P1_6==0){Delay(20);if(P1_6==0){while(P1_6==0);Delay(20);key=7;}}
    if(P1_5==0){Delay(20);if(P1_5==0){while(P1_5==0);Delay(20);key=11;}}//B
    if(P1_4==0){Delay(20);if(P1_4==0){while(P1_4==0);Delay(20);key=15;}}//F
    P1_1 = 1;

    // ��4�У�COL4=P1_0��
    P1_0 = 0;
    if(P1_7==0){Delay(20);if(P1_7==0){while(P1_7==0);Delay(20);key=4;}}
    if(P1_6==0){Delay(20);if(P1_6==0){while(P1_6==0);Delay(20);key=8;}}
    if(P1_5==0){Delay(20);if(P1_5==0){while(P1_5==0);Delay(20);key=12;}}//C
    if(P1_4==0){Delay(20);if(P1_4==0){while(P1_4==0);Delay(20);key=0;}}//0
    P1_0 = 1;

    return key;
}

// ��ʱ������12MHz����ms����
void Delay(unsigned int ms)
{
    unsigned int i, j;
    for(i = ms; i > 0; i--)
    {
        for(j = 114; j > 0; j--);
    }
}