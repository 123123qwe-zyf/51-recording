#include <REGX51.H>
void main()
{
	P1=0xFF;
}

	