#include <REGX51.H>
sbit bit1=P2^0;
sbit bit2=P2^1;
sbit bit3=P2^2;
sbit bit4=P2^3;
sbit bit5=P2^4;
sbit bit6=P2^5;
sbit bit7=P2^6;
sbit bit8=P2^7;
sbit button1=P3^0;
sbit button2=P3^1;
sbit led1=P1^0;
sbit led2=P1^1;
unsigned int min,sec,ms=0;
bit run_flag=0;
unsigned char code seg_table[] =
{
	0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F,0x40
};
unsigned char buf[8]={0,0,10,0,0,10,0,0};
void delay(unsigned int ms) 
{
	unsigned int i, j; // ���ѭ�����ƺ����� 
	for(i = ms; i > 0; i--) 
	{ 
		 for(j = 114; j > 0; j--);
	}
 }
void key(void)
{
	if(button1==0)
	{
		delay(20);
		if(button1==0)
		{
			run_flag=!run_flag;
			while(button1==0);
		}
	}
	if(button2==0)
	{
		delay(20);
		if(button2==0)
		{
			ms=0;sec=0;min=0;
			buf[0]=0; 
			buf[1]=0;
			buf[3]=0;
			buf[4]=0;
			buf[6]=0;
			buf[7]=0;
			led1=0;led2=0;
			while(button2==0);
		}
	}
}
void Timer0_Init(void)
{
	TMOD	&=0xF0;
	TMOD  |=0x01;
	TH0=0xDC;   
	TL0=0x00;
	ET0=1;      
	EA=1;        
	TR0=1;  
}
//10ms
void Timer0_Routine(void) interrupt 1
{
	TH0=0xDC;
	TL0=0x00;
	if(run_flag)
	{
		ms++;
		if(ms>99)
		{
			sec++;
			ms=0;
			if(sec>59)
			{
				min++;
				sec=0;
				if(min>59)
				{
					min=0;
				}
			}
		}
		buf[0]=min/10;
		buf[1]=min%10;
		buf[3]=sec/10;
		buf[4]=sec%10;
		buf[6]=(ms%100)/10;
		buf[7]=ms%10;
	}
}
void display(void)
{
    static unsigned char i = 0;
    P0 = 0x00;
    switch(i)
    {
        case 0: P0 = seg_table[buf[0]]; bit1 = 0; break;
        case 1: P0 = seg_table[buf[1]]; bit2 = 0; break;
        case 2: P0 = seg_table[buf[2]]; bit3 = 0; break;
        case 3: P0 = seg_table[buf[3]]; bit4 = 0; break;
        case 4: P0 = seg_table[buf[4]]; bit5 = 0; break;
        case 5: P0 = seg_table[buf[5]]; bit6 = 0; break;
        case 6: P0 = seg_table[buf[6]]; bit7 = 0; break;
        case 7: P0 = seg_table[buf[7]]; bit8 = 0; break;
    }
    delay(1);
    bit1 = bit2 = bit3 = bit4 = bit5 = bit6 = bit7 = bit8 = 1;
    i = (i + 1) % 8;
}
void time(void)
{
	unsigned int t;
	char time_str[20];
	t=min*60000+sec*1000+ms*10;
	led1=0;led2=0;
	if(t>=9500&&t<=10500)
	{
		led1=1;led2=0;
	}
	else if((t>=8500&&t<9500)||(t>10500&&t<=11500))
	{
		led1=1;led2=1;
	}
	else
	{
		led1=0;led2=0;
	}
}


void main(void)
{
	Timer0_Init();
	while(1)
	{
		key();
		display();
		time();
	}
}