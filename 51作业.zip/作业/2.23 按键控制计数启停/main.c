#include <REGX51.H>
unsigned char code seg_table[] =
{
	0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F
};


sbit b1=P3^0;
sbit led=P1^0;
sbit dig1=P2^1;
sbit dig2=P2^0;

void delay(unsigned int ms); 
void Timer0_Init(void);

unsigned int cnt=0;
unsigned int cntT=0;
static unsigned char dig_idx=0;

bit run_flag=0;

void main(void)
{
	Timer0_Init();
	led=0;
	while(1)
	{
		if(b1==0)
		{
			delay(20);
			if(b1==0)
			{
				run_flag=!run_flag;
				led=run_flag;
			}
		}
	}
}
void delay(unsigned int ms) 
{
	unsigned int i, j;
	for(i = ms; i > 0; i--) 
	{ 
		 for(j = 114; j > 0; j--);
	}
}

void Timer0_Init(void)
{
	TMOD	&=0xF0;    //���T0ģʽλ
	TMOD  |=0x01;     //T0ģʽ1��16λ��ʱ
	TH0=0xFC;            //��ֵ��8λ
	TL0=0x18;             //��ֵ��8λ
	ET0=1;                  //����T0�ж�
	EA=1;                    //�������ж�
	TR0=1;                  //����T0
}

void Timer0_Rountine(void) interrupt 1
{
	TH0=0xFC;
	TL0=0x18;
	cntT++;
	if(cntT>500)
	{
		cntT=0;
		if(run_flag)
		{
			cnt++;
			if(cnt>30)
				cnt=0;
		}
	}
	if(dig_idx==0)
	{
		P0=0x00;
		dig1=1;dig2=0;
		P0=seg_table[cnt/10];
	}
	else
	{
		P0=0x00;
		dig1=0;dig2=1;
		P0=seg_table[cnt%10];
	}
	dig_idx = !dig_idx;
}
