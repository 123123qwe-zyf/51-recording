#include <REGX51.H>

sbit led=P2^0;

static unsigned int cnt=0;

void Timer0_Init(void)
{
	TMOD&=0xF0;
	TMOD|=0x01;
	TH0=0xFC;
	TL0=0x18;
	ET0=1;
	EA=1;
	TR0=1;
}

void main(void)
{
	Timer0_Init();
	led=0;
	while(1)
	{
	}
}


void Timer0_Routine() interrupt 1
{
	TH0=0xFC;
	TL0=0x18;
	cnt++;
	if(cnt>=1000)
	{
		cnt=0;
		led=~led;
	}
}
