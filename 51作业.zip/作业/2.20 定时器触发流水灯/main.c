#include <REGX51.H>
sbit led1=P2^0;
sbit led2=P2^1;
sbit led3=P2^2;
sbit led4=P2^3;
sbit led5=P2^4;
sbit led6=P2^5;
sbit led7=P2^6;
sbit led8=P2^7;

unsigned int cnt=0;
unsigned char led_state=0;
unsigned char dir=1;

void delay(unsigned int ms);
void led_process(void);
void Timer0_Init(void);

void main(void)
{
	Timer0_Init();
	P2=0x00;
	while(1)
	{
		led_process();
	}
}


void delay(unsigned int ms) 
{
	unsigned int i, j; 
	for(i = ms; i > 0; i--) 
	{ 
		 for(j = 114; j > 0; j--);
	}
 }
void led_process(void)
{
	P2=0x00;
	switch(led_state)
	{
		case 0:led1=1;break;
		case 1:led2=1;break;
		case 2:led3=1;break;
		case 3:led4=1;break;
		case 4:led5=1;break;
		case 5:led6=1;break;
		case 6:led7=1;break;
		case 7:led8=1;break;

	}
}
 
void Timer0_Init(void)
{
	TMOD	&=0xF0;    //���T0ģʽλ
	TMOD  |=0x01;     //T0ģʽ1��16λ��ʱ
	TH0=0xFC;            //��ֵ��8λ
	TL0=0x18;             //��ֵ��8λ
	ET0=1;                  //����T0�ж�
	EA=1;                    //�������ж�
	TR0=1;                  //����T0
}
void Timer0_rountine() interrupt 1
{
	TH0=0xFC;
	TL0=0x18;
	cnt++;
	if(cnt>=10)
	{
		cnt=0;
		if(dir==1)
		{
			led_state++;
			if(led_state>=7)
			{
				dir=0;
			}
		}
		else
		{
			led_state--;
			if(led_state==0)
			{
				dir=1;
			}
		}
	}
}
