#include <REGX51.H>
sbit bit1=P2^2;
sbit bit2=P2^1;

sbit ROW1 = P1^7;
sbit ROW2 = P1^6;
sbit ROW3 = P1^5;
sbit ROW4 = P1^4;

sbit COL1 = P1^3;
sbit COL2 = P1^2;
sbit COL3 = P1^1;
sbit COL4 = P1^0;

unsigned char code seg_table[] = {0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F,0x77,0x7C,0x39,0x5E,0x79,0x71};
unsigned char KeyNumber;

void delayms(unsigned int ms);
void display(unsigned char num);
unsigned char MatrixKey();

void main(void)
{
	while(1)
	{
		KeyNumber=MatrixKey();
		display(KeyNumber);
	}
}

//��ʱ ����
void delayms(unsigned int ms) 
{
	unsigned int i, j; // ���ѭ�����ƺ����� 
	for(i = ms; i > 0; i--) 
	{ 
		// �ڲ�ѭ��ʵ��1ms��ʱ��12MHz�����£�Լ1000���������ڣ�
		 for(j = 114; j > 0; j--);
	}
}
//�������ʾ
void display(unsigned char keynum)
{
	unsigned char shi=keynum/10;
	unsigned char ge=keynum%10;
	P0=0x00;
	bit1=1;bit2=0;
	P0=seg_table[shi];
	delayms(2);
	
	P0=0x00;
	bit1=0;bit2=1;
	P0=seg_table[ge];
	delayms(2);
}
unsigned char MatrixKey()
{
		P1 = 0xFF;          // �˿ڳ�ʼ��
    COL1 = 0;           // ���͵�һ��
    if(ROW1 == 0){delayms(20);while(ROW1==0);delayms(20);KeyNumber=1;}
    if(ROW2 == 0){delayms(20);while(ROW2==0);delayms(20);KeyNumber=5;}
    if(ROW3 == 0){delayms(20);while(ROW3==0);delayms(20);KeyNumber=9;}
    if(ROW4 == 0){delayms(20);while(ROW4==0);delayms(20);KeyNumber=13;}
    P1 = 0xFF;
    COL2 = 0;           
    if(ROW1 == 0){delayms(20);while(ROW1==0);delayms(20);KeyNumber=2;}
    if(ROW2 == 0){delayms(20);while(ROW2==0);delayms(20);KeyNumber=6;}
    if(ROW3 == 0){delayms(20);while(ROW3==0);delayms(20);KeyNumber=10;}
    if(ROW4 == 0){delayms(20);while(ROW4==0);delayms(20);KeyNumber=14;}
    P1 = 0xFF;
    COL3 = 0;           
    if(ROW1 == 0){delayms(20);while(ROW1==0);delayms(20);KeyNumber=3;}
    if(ROW2 == 0){delayms(20);while(ROW2==0);delayms(20);KeyNumber=7;}
    if(ROW3 == 0){delayms(20);while(ROW3==0);delayms(20);KeyNumber=11;}
    if(ROW4 == 0){delayms(20);while(ROW4==0);delayms(20);KeyNumber=15;}
    P1 = 0xFF;
    COL4 = 0;
    if(ROW1 == 0){delayms(20);while(ROW1==0);delayms(20);KeyNumber=4;}
    if(ROW2 == 0){delayms(20);while(ROW2==0);delayms(20);KeyNumber=8;}
    if(ROW3 == 0){delayms(20);while(ROW3==0);delayms(20);KeyNumber=12;}
    if(ROW4 == 0){delayms(20);while(ROW4==0);delayms(20);KeyNumber=16;}
    return KeyNumber;
} 
