#include <REGX51.H>
void delay_ms(unsigned int ms)
{
	unsigned int i,j;
	for(i=0;i<ms;i++)
		for(j=0;j<120;j++);
}
void main()
{
	unsigned char i;
	signed char dir=1;
	while(1)
	{
		P1=(0x01<<i);
		delay_ms(150);
		i+=dir;
		if(i>=7)
			dir=-1;
		else if(i==0)
			dir=1;
	}
}